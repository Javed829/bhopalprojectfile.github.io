const Fedds=[
    {
        name: "Hamburger",
        price: "200",
        image: "images/burger.jpeg"
    },
    {
        name: "Fries",
        price: "100",
        image: "images/fries.jpeg"
    },
    {
        name: "Coke",
        price: "50",
        image: "images/coke.jpeg"
    },
    {
        name: "Pepsi",
        price: "50",
        image: "images/pepsi.jpeg"
    }
]
export default Fedds